# Book-Store-Management-System
created a book store management system using MySql + Thymeleaf+ Spring Data JPA(Spring Boot project)
